const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const handlebars = require('express-handlebars');

const app=express();

//configurando o body-parser
const urlencodeParser = bodyParser.urlencoded({extended: false});


//conectando com o banco de dados
const sql = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '1234',
    port: 3306
});
sql.query("use teste");


//configurando templete(handlebars)
app.engine("handlebars",handlebars({defaultLayout:'main'}));
app.set('view engine', 'handlebars');

//configurando css,js,img 
app.use('/css',express.static('css'));
app.use('/js',express.static('js'));
app.use('/img',express.static('img'));



app.get("/calc",function(req,res){
res.render('calc');
    });


     app.get("/", function(req, res){
       
            res.render('index');
        });
        
        app.get("/inserir",function(req,res){
            res.render("inserir");
        });
        
        app.get("/sobre", function(req, res){
            res.render("sobre");
        });
        
        
        app.get("/select/:cpf?", function(req,res){
            if(!req.params.cpf){
                sql.query("select * from usuario", function(erro, results, fields){
                    res.render("select", {data:results});
                });
            }
        });

        app.get("/falc",function(req,res){
            res.render('falc');
                 });

        app.get("/apagar/:cpf", function(req,res){
                sql.query("delete from usuario where cpf=?", [req.params.cpf]);
                    res.render("apagar");
        });
        
        
        
        app.get("/update/:cpf", function(req,res){
            sql.query("select * from usuario where cpf=?",[req.params.cpf], function(erro,results,fields){
                res.render("update", {cpf:req.params.cpf,nome:results[0].nome,email:results[0].email});
            });
        });
        
        app.post("/controllerupdate",urlencodeParser,function(req,res){
            sql.query("update usuario set cpf=?, nome=?, email=? where cpf=?", [req.body.cpf,req.body.nome,req.body.email,req.body.cpf]);
            res.render("controllerupdate");
        });
        
        app.post("/controlleradd",urlencodeParser,function(req, res){
            sql.query("insert into usuario values(?,?,?)", [req.body.cpf,req.body.nome,req.body.email]);
            res.send("Cadastro com sucesso");
        });
        
        app.post("/newuser",urlencodeParser,function(req, res){
            sql.query("insert into aluno values(?,?,?,?,?,?)", [req.body.turma,req.body.curso,req.body.unidade,req.body.disciplina,req.body.aluno,req.body.professor]);
            res.send("Aluno registrado com sucesso");
        });
        
        //Iniciando servidor http
        
        app.listen(1999, function(req,res){
            console.log('Servidor funcionando!');
        });